import React from 'react';
import heartImg from "../assets/heart.png";
import shareImg from "../assets/share.png";
import "./card.scss";

interface ICARD {
  logoUrl: string;
  title: string;
  subTitle?: string;
  favorite:{isFavorite:boolean,setIsFavorite():void}|null;
  bannerImgUrl: string;
  typography: string;
  actions: {
    actionOne: {text:string; onClick():void; },
    actionTwo?: {text:string; onClick():void; },
    actionShare: { onClick():void; },
  }
}

export const  Card:React.FC<ICARD>=({logoUrl,title,subTitle,bannerImgUrl,typography,actions:{actionOne,actionTwo,actionShare},favorite})=> {
  return (
    <div className="card-wrap">
      <div className="card">
        <div className="card-header">
          <a href="#" className="card-logo">
            <img src={logoUrl} />
          </a>
          <div className="card-title">
            <h2>{title}</h2>
            <h5>{subTitle}</h5>
          </div>
        </div>
        <div className="card-banner">
          <img src={bannerImgUrl} />
        </div>
        <div className="card-content">
          <p>{typography}</p>
        </div>
        <div className="card-footer">
          <div className="action-links">
            <button onClick={actionOne.onClick} className="btn-login">{actionOne.text}</button>
            {actionTwo&&   <button onClick={actionTwo.onClick}  className="btn-reg">{actionTwo.text}</button>}
          </div>
          <div className="social-links">
         {favorite&& <button onClick={favorite.setIsFavorite} className="btn-share">
          <img src={heartImg} alt=""/>
            </button>}
            <button onClick={actionShare.onClick} className="btn-share">
            <img src={shareImg} alt=""/>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}


