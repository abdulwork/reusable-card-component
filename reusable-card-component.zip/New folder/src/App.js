import React from 'react';
import './App.css';
import logoSvg from "./assets/logo.svg";
import bannerImg from "./assets/banner.png";

import {Card } from "./components/card.tsx";

function App() {
  return (
    <div className="App">
      <Card title="title" logoUrl={logoSvg} subTitle="Secondary Text" typography="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua." bannerImgUrl={bannerImg} actions={{ actionOne:{text:"Login",onClick:()=>undefined}, actionTwo:{text:"Register",onClick:()=>undefined},actionShare:{onClick:()=>undefined} }}
      favorite={{isFavorite:true,setIsFavorite:()=>undefined}} />
    </div>
  );
}

export default App;
